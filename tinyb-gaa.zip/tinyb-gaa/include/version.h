#pragma once

extern const char* gVERSION;
extern const char* gVERSION_SHORT;
extern const char* gVERSION_API;
