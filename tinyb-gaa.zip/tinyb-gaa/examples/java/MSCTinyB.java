import tinyb.*;

import java.util.*;
import java.time.Duration;
import java.nio.ByteBuffer;
import java.util.concurrent.locks.*;
import java.util.concurrent.TimeUnit;

public class MSCTinyB {
    private static final float SCALE_LSB = 0.03125f;
    static boolean running = true;

    static void printDevice(BluetoothDevice device) {
        System.out.print("Address = " + device.getAddress());
        System.out.print(" Name = " + device.getName());
        System.out.print(" Connected = " + device.getConnected());
        System.out.println();
    }

    static float convertCelsius(int raw) {
        return raw / 128f;
    }

    /*
     * After discovery is started, new devices will be detected. We can get a list of all devices through the manager's
     * getDevices method. We can the look through the list of devices to find the device with the MAC which we provided
     * as a parameter. We continue looking until we find it, or we try 15 times (1 minutes).
     */
    static BluetoothDevice getDevice(String address) throws InterruptedException {
        BluetoothManager manager = BluetoothManager.getBluetoothManager();
        BluetoothDevice sensor = null;
        for (int i = 0; (i < 15) && running; ++i) {
            List<BluetoothDevice> list = manager.getDevices();
            if (list == null)
                return null;

            for (BluetoothDevice device : list) {
                printDevice(device);
                /*
                 * Here we check if the address matches.
                 */
                if (device.getAddress().equals(address))
                    sensor = device;
            }

            if (sensor != null) {
                return sensor;
            }
            Thread.sleep(4000);
        }
        return null;
    }

    /*
     * Our device should expose a temperature service, which has a UUID we can find out from the data sheet. The service
     * description of the SensorTag can be found here:
     * http://processors.wiki.ti.com/images/a/a8/BLE_SensorTag_GATT_Server.pdf. The service we are looking for has the
     * short UUID AA00 which we insert into the TI Base UUID: f000XXXX-0451-4000-b000-000000000000
     */
    static BluetoothGattService getService(BluetoothDevice device, String UUID) throws InterruptedException {
        System.out.println("Services exposed by device:");
        BluetoothGattService tempService = null;
        List<BluetoothGattService> bluetoothServices = null;
        do {
            bluetoothServices = device.getServices();
            for (BluetoothGattService service: bluetoothServices) {
                System.out.println(service.getUUID());
            }
            if (bluetoothServices == null)
                return null;

            for (BluetoothGattService service : bluetoothServices) {
                System.out.println("UUID: " + service.getUUID());
                if (service.getUUID().equals(UUID))
                    tempService = service;
            }
            Thread.sleep(4000);
        } while (bluetoothServices.isEmpty() && running);
        return tempService;
    }

    static BluetoothGattCharacteristic getCharacteristic(BluetoothGattService service, String UUID) {
        List<BluetoothGattCharacteristic> characteristics = service.getCharacteristics();
        if (characteristics == null)
            return null;

        for (BluetoothGattCharacteristic characteristic : characteristics) {
            if (characteristic.getUUID().equals(UUID))
                return characteristic;
        }
        return null;
    }

    /*
     * This program connects to a TI SensorTag 2.0 and reads the temperature characteristic exposed by the device over
     * Bluetooth Low Energy. The parameter provided to the program should be the MAC address of the device.
     *
     * A wiki describing the sensor is found here: http://processors.wiki.ti.com/index.php/CC2650_SensorTag_User's_Guide
     *
     * The API used in this example is based on TinyB v0.3, which only supports polling, but v0.4 will introduce a
     * simplied API for discovering devices and services.
     */
    public static void main(String[] args) throws InterruptedException {

        /*
         * To start looking of the device, we first must initialize the TinyB library. The way of interacting with the
         * library is through the BluetoothManager. There can be only one BluetoothManager at one time, and the
         * reference to it is obtained through the getBluetoothManager method.
         */
        BluetoothManager manager = BluetoothManager.getBluetoothManager();

        /*
         * The manager will try to initialize a BluetoothAdapter if any adapter is present in the system. To initialize
         * discovery we can call startDiscovery, which will put the default adapter in discovery mode.
         */
        boolean discoveryStarted = manager.startDiscovery();

        System.out.println("The discovery started: " + (discoveryStarted ? "true" : "false"));

        while (true) {

            for (BluetoothDevice device : manager.getDevices()) {

                //printDevice(device); (TIREI ESTE PARA O WHILE TRUE NAO SPAMMAR DEMASIADO)


                //System.out.println("SERVICES: " + device.getServices());
                //System.out.println("getUUIDs: " + device.getUUIDs());
                Map<String, byte[]> serviceData = device.getServiceData();
                //System.out.println("getServiceData: " + serviceData);
                for (byte[] byteArray : serviceData.values()) {
                    //System.out.println(byteArray.length);
                    if (byteArray.length == 12) {

                        byte[] encrypted = "lollollollol".getBytes(); // lol...

                        for (int i = 0; i < encrypted.length; i++) {
                            byteArray[i] ^= encrypted[i];
                        }

                        byte[] stepsBytes = Arrays.copyOfRange(byteArray, 0, 4);
                        int steps = ByteBuffer.wrap(stepsBytes).getInt();
                        byte[] timestampBytes = Arrays.copyOfRange(byteArray, 4, byteArray.length);
                        long timestamp = ByteBuffer.wrap(timestampBytes).getLong();

                        System.out.println("Steps: " + steps + " | Timestamp: " + timestamp );  // tirei o + "\n" do fim para o while true

                    } else {
                        System.out.println("Byte array recieved doesn't have the expected length.");
                    }

                }

                // I'd really love to know why we need this Thread.sleep here but to be honest I have no clue.
                // pls no remove thx
                Thread.sleep(100);


                //System.out.println("find: " + device.find("0000ab5c-0000-1000-8000-00805f9b34fb", Duration.ofSeconds(3)));





                //System.out.println("getService: " + getService(device, "9e96ab5c-75a8-11e9-95e1-2a86e4085a59"));

                /*
                 * Here we check if the address matches.
                 */

                /*if (device.getAddress().equals(address))
                    sensor = device;*/

            }
            System.out.println("\n-----------------------------------\n");
            Thread.sleep(5000);
        }
    }
}
